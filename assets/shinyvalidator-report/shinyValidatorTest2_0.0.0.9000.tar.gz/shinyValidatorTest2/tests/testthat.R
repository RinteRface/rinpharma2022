library(testthat)
library(shinyValidatorTest2)

test_check("shinyValidatorTest2")
